import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EditarCategoriasComponent } from './editar-categorias/editar-categorias.component';
import { ListaCategoriasComponent } from './lista-categorias/lista-categorias.component';
import { CategoriasService } from './shared/categorias.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    EditarCategoriasComponent,
    ListaCategoriasComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    CategoriasService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
