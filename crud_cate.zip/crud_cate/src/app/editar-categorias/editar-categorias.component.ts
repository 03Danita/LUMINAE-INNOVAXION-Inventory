import { Component } from '@angular/core';
import { CategoriasModel } from '../shared/categorias.model';
import { CategoriasService } from '../shared/categorias.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-editar-categorias',
  templateUrl: './editar-categorias.component.html',
  styleUrls: ['./editar-categorias.component.css']
})
export class EditarCategoriasComponent {
  id = '';
  categorias = new CategoriasModel("", "", "",)

  constructor(
    private categoriasService: CategoriasService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    if (this.id) {
      console.log("EDITAR");
      this.categoriasService.obtenerCategoriasPorId(this.id).subscribe((data: any[]) => {
        this.categorias = data[0];
      }, (error: any) => {
        console.log(error);
      });
    } else {
      console.log("CREAR");
    }
  }

  onSubmit() {
    console.log('onSubmit');

    if (this.categorias.id) {
      this.categoriasService.actualizarCategorias(this.categorias).subscribe(data => {
        alert(data);
        this.router.navigate(['/categorias']);
      });
    } else {
      console.log('crear');
      this.categoriasService.agregarCategorias(this.categorias).subscribe(data => {
        alert(data);
        this.router.navigate(['/categorias']);
      });
    }
  }
}
