import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CategoriasModel } from './categorias.model';


@Injectable({
  providedIn: 'root'
})
export class CategoriasService {

  
  BASE_URL = "http://localhost:3000";

  constructor(private http: HttpClient) { }

  obtenerCategorias() {
    return this.http.get<CategoriasModel[]>(`${this.BASE_URL}/categorias`);
  }

  obtenerCategoriasPorId(id: string) {
    return this.http.get<CategoriasModel[]>(`${this.BASE_URL}/categorias/${id}`);
  }

  agregarCategorias(categorias: CategoriasModel) {
    return this.http.post<string>(`${this.BASE_URL}/categorias/agregar`, categorias);
  }

  actualizarCategorias(categorias: CategoriasModel) {
    return this.http.put<string>(`${this.BASE_URL}/categorias/actualizar/${categorias.id}`, categorias);
  }

  borrarCategorias(id: string) {
    return this.http.delete<string>(`${this.BASE_URL}/categorias/borrar/${id}`);
  }
}
