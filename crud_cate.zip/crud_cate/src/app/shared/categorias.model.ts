export class CategoriasModel {

    constructor(
      public id: string,
      public nombre: string,
      public categorias: string

    ) { }
  
  }