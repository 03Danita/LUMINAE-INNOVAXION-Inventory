import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { CategoriasService } from '../shared/categorias.service';
import { CategoriasModel } from '../shared/categorias.model';

@Component({
  selector: 'app-lista-categorias',
  templateUrl: './lista-categorias.component.html',
  styleUrls: ['./lista-categorias.component.css']
})
export class ListaCategoriasComponent {
  categorias: Observable<CategoriasModel[]> | undefined;

  constructor(private categoriasService: CategoriasService) { }

  ngOnInit() {
    this.categorias = this.categoriasService.obtenerCategorias();
  }

  borrarCategorias(id: string) {
    this.categoriasService.borrarCategorias(id).subscribe((data: any) => {
      console.log(data);
    });
  }
}
