import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListaCategoriasComponent } from './lista-categorias/lista-categorias.component';
import { EditarCategoriasComponent } from './editar-categorias/editar-categorias.component';

const routes: Routes = [
  { path: 'categorias', component: ListaCategoriasComponent },
  { path: 'categorias/editar/:id', component: EditarCategoriasComponent },
  { path: 'categorias/agregar', component: EditarCategoriasComponent },
  { path: '**', redirectTo: '/categorias', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
