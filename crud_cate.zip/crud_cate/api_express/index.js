const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', '*');
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.json());

const PUERTO = 3000;

const conexion = mysql.createConnection(
    {
        host: 'localhost',
        database: 'categorias',
        user: 'root',
        password: ''
    }
);

app.listen(PUERTO, () => {
    console.log(`Servidor corriendo en el puerto ${PUERTO}`);
});

conexion.connect(error => {
    if (error) throw error;
    console.log('Conexión exitosa a la base de datos');
});

app.get('/', (req, res) => {

    res.send('API');
});

app.get('/categorias', (req, res) => {
    const query = `SELECT * FROM categorias;`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
        }
    })
})

app.get('/categorias/:id', (req, res) => {
    const { id } = req.params

    const query = `SELECT * FROM categorias WHERE id=${id};`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
        }
    })
})

app.post('/categorias/agregar', (req, res) => {
    const categorias = {
        nombre: req.body.nombre,
        categorias: req.body.categorias
    }

    const query = `INSERT INTO categorias SET ?`
    conexion.query(query, categorias, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se insertó correctamente el usuario`)
    })
})

app.put('/categorias/actualizar/:id', (req, res) => {
    const { id } = req.params
    const { nombre, categorias } = req.body

    const query = `UPDATE categorias SET nombre='${nombre}', categorias='${categorias}' WHERE id='${id}';`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se actualizó correctamente el usuario`)
    })
})

app.delete('/categorias/borrar/:id', (req, res) => {
    const { id } = req.params

    const query = `DELETE FROM categorias WHERE id=${id};`
    conexion.query(query, (error) => {
        if(error) console.error(error.message)

        res.json(`Se eliminó correctamente el usuario`)
    })
})